import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  ArrowDownRight,
  ArrowUpRight,
  Check,
  ChevronDown,
  CircleCheck,
  FileUp,
  Menu,
  MessageCircle,
  MoveRight,
  PackageCheck,
  Sparkles,
  X,
} from 'lucide-react';
import './styles.css';

const products = [
  { tag: '主打系列', title: '高级手提纸袋', description: '挺括纸张与柔软提手的平衡，让品牌从门店走向街头。', specs: ['500 起订', '12 天交期', '白卡 / 250g'], accent: 'champagne' },
  { tag: '环保系列', title: '再生牛皮纸袋', description: '保留自然纸纹与温暖触感，为咖啡、烘焙和生活方式品牌而生。', specs: ['300 起订', '10 天交期', '再生纸 / 180g'], accent: 'kraft' },
  { tag: '精品系列', title: '烫金礼赠袋', description: '细腻的压纹纸面配合金属光泽，承托珠宝、美妆与高端礼赠。', specs: ['200 起订', '15 天交期', '特种纸 / 300g'], accent: 'ink' },
  { tag: '轻量系列', title: '平口折叠袋', description: '轻便、节省仓储空间，适合活动物料、快闪店与批量发放。', specs: ['1000 起订', '8 天交期', '白牛皮 / 160g'], accent: 'sand' },
];

const materials = [
  { icon: '✦', title: '金银箔印', forText: '适合：美妆、珠宝、精品零售', copy: '让品牌标识在光线移动时产生层次，细线与小字也能清晰呈现。' },
  { icon: '◌', title: '细腻压纹', forText: '适合：香氛、家居、生活方式', copy: '在纸面留下可触摸的品牌记忆，低调但足够有辨识度。' },
  { icon: '◒', title: '局部 UV', forText: '适合：科技、活动、年轻品牌', copy: '用亮面与哑面做对比，让图形、字标和图案拥有视觉焦点。' },
  { icon: '▧', title: '专色与专纸', forText: '适合：连锁、出版、酒店品牌', copy: '根据品牌色与触感选择纸张，建立从视觉到手感的一致性。' },
  { icon: '⌁', title: '棉绳与丝带', forText: '适合：礼赠、时装、节日限定', copy: '提手不只是承重结构，也是用户拿起纸袋时的第一触点。' },
  { icon: '◎', title: '可持续材料', forText: '适合：环保、餐饮、自然品牌', copy: '再生纸、水性油墨与可回收结构，减少不必要的包装负担。' },
];

const faqs = [
  ['纸袋的起订量是多少？', '常规手提袋可从 300–500 个起订，特殊纸张、复杂结构或小批量礼赠项目可根据需求单独评估。'],
  ['可以先看实物样品吗？', '可以。确认尺寸、纸张和工艺方向后，我们会先制作数字效果图，再安排实物打样供你确认。'],
  ['从设计到交付需要多久？', '常规项目通常在确认设计后 8–15 个工作日完成生产；复杂工艺和大批量项目会在报价时给出明确计划。'],
  ['可以使用环保纸张和油墨吗？', '可以。我们会根据使用场景推荐再生纸、FSC 方向纸张和水性油墨等方案，并在报价中拆分说明。'],
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState(0);
  const [submitted, setSubmitted] = useState(false);

  const closeMenu = () => setMenuOpen(false);
  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="site-shell">
      <a className="skip-link" href="#main">跳到主要内容</a>
      <header className="topbar">
        <a className="brand" href="#top" onClick={closeMenu} aria-label="Paper Bag Works 首页">
          <span className="brand-mark">P</span>
          <span><strong>PAPER</strong><em>BAG WORKS</em><small>纸袋工坊</small></span>
        </a>
        <nav className={menuOpen ? 'main-nav is-open' : 'main-nav'} aria-label="主导航">
          <a href="#products" onClick={closeMenu}>产品系列</a>
          <a href="#materials" onClick={closeMenu}>材质工艺</a>
          <a href="#process" onClick={closeMenu}>合作流程</a>
          <a href="#faq" onClick={closeMenu}>常见问题</a>
          <a className="nav-quote" href="#quote" onClick={closeMenu}>获取报价 <ArrowUpRight size={14} /></a>
        </nav>
        <button className="menu-toggle" type="button" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? '关闭菜单' : '打开菜单'} aria-expanded={menuOpen}>
          {menuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </header>

      <main id="main">
        <section className="hero" id="top">
          <div className="hero-image" aria-hidden="true"><div className="hero-bag-scene"><div className="hero-bag bag-one"><div className="hero-bag-handle" /><div className="hero-bag-body"><small>PAPER BAG</small><strong>WORKS</strong></div></div><div className="hero-bag bag-two"><div className="hero-bag-handle" /><div className="hero-bag-body"><small>PAPER BAG</small><strong>WORKS</strong></div></div><div className="hero-paper-note">PAPER / HANDLE / FINISH</div></div></div>
          <div className="hero-overlay" aria-hidden="true" />
          <div className="hero-content section-pad">
            <div className="eyebrow"><Sparkles size={14} /> 定制纸袋制造伙伴 · Paper Bag Works</div>
            <h1>让品牌的<br /><span>光</span>，落在纸上。</h1>
            <p className="hero-copy">从一张纸开始，为零售、餐饮与礼赠品牌打造有触感、有记忆点的定制纸袋。</p>
            <ul className="hero-points">
              <li><CircleCheck size={17} /> 免费结构建议与数字效果图</li>
              <li><CircleCheck size={17} /> 纸张、提手、工艺一站式定制</li>
            </ul>
            <div className="hero-actions">
              <a className="button primary" href="#quote">开始定制 <ArrowUpRight size={18} /></a>
              <a className="text-link" href="#products">查看纸袋系列 <MoveRight size={18} /></a>
            </div>
            <div className="hero-pills" aria-label="服务信息">
              <div><strong>300+</strong><span>起订数量</span></div>
              <div><strong>8–15</strong><span>工作日交期</span></div>
              <div><strong>24h</strong><span>设计响应</span></div>
              <div><strong>全球</strong><span>物流支持</span></div>
            </div>
          </div>
          <a className="scroll-cue" href="#intro" aria-label="向下浏览"><ArrowDownRight size={20} /> SCROLL TO EXPLORE</a>
        </section>

        <section className="trust-strip section-pad" id="intro">
          <div className="section-heading compact-heading"><span className="eyebrow">从纸张到成品</span><h2>做一个真正代表你的<br /><i>纸袋。</i></h2></div>
          <p className="trust-copy">我们把包装当成品牌体验的一部分。从纸张克重、折边比例，到手提绳的触感，每个细节都服务于你想留下的那一秒印象。</p>
          <div className="stats-grid">
            <div><strong>2,000+</strong><span>品牌项目经验</span></div>
            <div><strong>18</strong><span>种纸张与纹理</span></div>
            <div><strong>6</strong><span>类主流工艺</span></div>
            <div><strong>100%</strong><span>出厂前质检</span></div>
          </div>
        </section>

        <section className="section-pad dark-section" id="products">
          <div className="section-heading"><span className="eyebrow">COLLECTION / 01</span><h2>为每一次<br /><i>被看见</i>准备。</h2><p>从日常购物袋到限定礼赠袋，选择结构，再让纸张、颜色和工艺把品牌说完整。</p></div>
          <div className="product-grid">
            {products.map((product, index) => (
              <article className={`product-card accent-${product.accent}`} key={product.title}>
                <div className="product-visual">
                  <div className="bag-illustration" aria-hidden="true"><div className="bag-handle" /><div className="bag-body"><span>PBW</span><small>{index === 0 ? 'SIGNATURE' : index === 1 ? 'RAW PAPER' : index === 2 ? 'SIGNATURE' : 'EVERYDAY'}</small></div></div>
                  <span className="product-number">0{index + 1}</span>
                </div>
                <div className="product-card-body"><span className="tag-pill">{product.tag}</span><h3>{product.title}</h3><p>{product.description}</p><div className="spec-row">{product.specs.map((spec) => <span key={spec}>{spec}</span>)}</div><a href="#quote" className="card-link">询问这款纸袋 <ArrowUpRight size={15} /></a></div>
              </article>
            ))}
          </div>
        </section>

        <section className="section-pad materials-section" id="materials">
          <div className="section-heading centered"><span className="eyebrow">MATERIALS / 02</span><h2>同一只纸袋，<br /><i>不同的触感。</i></h2><p>表面工艺改变光的走向，纸张触感改变用户对品牌的判断。我们帮你找到刚刚好的组合。</p></div>
          <div className="material-grid">{materials.map((material) => <article className="material-card" key={material.title}><span className="material-icon">{material.icon}</span><h3>{material.title}</h3><span className="material-for">{material.forText}</span><p>{material.copy}</p></article>)}</div>
          <div className="material-callout"><div><span className="eyebrow">SAMPLE KIT</span><h3>在下单前，先把纸张拿在手里。</h3><p>告诉我们你的品牌方向，我们会整理一份适合的纸张与工艺组合建议。</p></div><a className="button outline" href="#quote">申请材质建议 <ArrowUpRight size={17} /></a></div>
        </section>

        <section className="factory-section section-pad" id="process">
          <div className="factory-visual"><div className="factory-glow" /><div className="factory-paper"><span>纸袋工坊</span><strong>从一张纸<br />到一件作品</strong><small>PAPER BAG WORKS / WORKSHOP NOTE 01</small></div><span className="factory-stamp">MADE WITH<br />ATTENTION</span></div>
          <div className="factory-copy"><span className="eyebrow">THE PAPER BAG WORKS ADVANTAGE</span><h2>不只是印一个<br /><i>Logo。</i></h2><p>稳定的结构、清晰的沟通、可追踪的交付，让每一个纸袋项目都更接近你最初想象的样子。</p><div className="feature-list"><div><PackageCheck size={22} /><span><strong>结构先行</strong><small>先确认容量、承重与折叠方式，再确定视觉。</small></span></div><div><Sparkles size={22} /><span><strong>免费设计支持</strong><small>从品牌文件到可生产的印刷稿，一起完成。</small></span></div><div><CircleCheck size={22} /><span><strong>每批次质检</strong><small>印刷、成型、提手与包装逐项检查。</small></span></div></div><a className="text-link" href="#quote">了解合作方式 <MoveRight size={18} /></a></div>
        </section>

        <section className="compare-section section-pad dark-section"><div className="section-heading centered"><span className="eyebrow">WHY PAPER BAG WORKS / 03</span><h2>让包装成为<br /><i>品牌资产。</i></h2></div><div className="compare-grid"><div className="compare-card muted"><span className="compare-label">普通印刷下单</span><h3>只解决“装得下”</h3>{['模板化尺寸与纸张', '沟通节点分散', '看不到生产过程', '工艺选择有限'].map((item) => <p key={item}><X size={17} />{item}</p>)}</div><div className="compare-card featured"><span className="compare-label">Paper Bag Works · 定制服务</span><h3>一起做好“被记住”</h3>{['从品牌目标反推结构', '一位顾问全程跟进', '样品确认后再批量生产', '纸张与工艺自由组合'].map((item) => <p key={item}><Check size={17} />{item}</p>)}<a className="button primary" href="#quote">开始聊聊你的项目 <ArrowUpRight size={17} /></a></div></div></section>

        <section className="section-pad faq-section" id="faq"><div className="faq-intro"><span className="eyebrow">FAQ / 04</span><h2>关于纸袋的<br /><i>几个问题。</i></h2><p>如果你的问题没有出现在这里，欢迎直接把需求发给我们。</p><a className="text-link" href="#quote">直接咨询 <MoveRight size={18} /></a></div><div className="faq-list">{faqs.map(([question, answer], index) => <div className={openFaq === index ? 'faq-item is-open' : 'faq-item'} key={question}><button type="button" onClick={() => setOpenFaq(openFaq === index ? -1 : index)}><span>{question}</span><ChevronDown size={19} /></button>{openFaq === index && <p>{answer}</p>}</div>)}</div></section>

        <section className="quote-section section-pad" id="quote"><div className="quote-card"><div className="quote-intro"><span className="eyebrow">START A PROJECT</span><h2>把你的想法，<br /><i>交给纸。</i></h2><p>填写基础信息，我们会在 24 小时内回复尺寸建议、材质方向与初步报价。</p><div className="consultant"><span className="consultant-avatar">P</span><span><strong>Paper Bag Works 顾问团队</strong><small><b /> 在线 · 通常 2 小时回复</small></span></div><ul className="trust-list"><li><Check size={16} /> 免费设计建议</li><li><Check size={16} /> 样品确认后生产</li><li><Check size={16} /> 信息仅用于项目沟通</li></ul></div><form className="quote-form" onSubmit={handleSubmit}><div className="form-row"><label>你的称呼<input required placeholder="例如：Alex" /></label><label>公司 / 品牌<input required placeholder="品牌名称" /></label></div><div className="form-row"><label>邮箱地址<input required type="email" placeholder="name@brand.com" /></label><label>联系电话<input placeholder="+86" /></label></div><div className="form-row"><label>纸袋类型<select defaultValue=""><option value="" disabled>选择纸袋类型</option><option>高级手提纸袋</option><option>再生牛皮纸袋</option><option>烫金礼赠袋</option><option>还不确定</option></select></label><label>预计数量<select defaultValue=""><option value="" disabled>选择数量范围</option><option>300–1,000 个</option><option>1,000–5,000 个</option><option>5,000 个以上</option></select></label></div><label>尺寸与工艺需求<textarea rows="3" placeholder="例如：220 × 120 × 280 mm，黑色纸张，金色 Logo，棉绳提手……" /></label><label className="upload-box"><FileUp size={22} /><span>上传 Logo 或参考文件<small>PNG / AI / PDF，最大 10MB</small></span><input type="file" accept=".png,.ai,.pdf" /></label><button className="button form-submit" type="submit">{submitted ? '已收到，我们会尽快联系你' : '获取免费打样报价'} <ArrowUpRight size={18} /></button>{submitted && <p className="success-message">感谢你的项目信息。当前为演示表单，提交内容未发送到服务器。</p>}</form></div></section>
      </main>

      <footer className="footer section-pad"><div className="footer-grid"><div className="footer-brand"><a className="brand" href="#top"><span className="brand-mark">P</span><span><strong>PAPER</strong><em>BAG WORKS</em><small>纸袋工坊</small></span></a><p>一只纸袋，带着品牌走进生活。<br />定制纸袋与包装体验设计。</p></div><div><h3>浏览</h3><a href="#products">纸袋系列</a><a href="#materials">材质与工艺</a><a href="#process">合作流程</a></div><div><h3>帮助</h3><a href="#faq">常见问题</a><a href="#quote">获取报价</a><a href="#quote">申请样品</a></div><div><h3>联系我们</h3><p className="contact-text">hello@paperbagworks.com<br />+86 400 888 2024<br />中国 · 服务全球</p><div className="footer-badges"><span>QUALITY<br />CHECKED</span><span>LOW<br />WASTE</span></div></div></div><div className="footer-bottom"><span>© 2026 Paper Bag Works · 纸袋工坊</span><span>原创品牌体验 · 定制纸袋制造</span></div></footer>
      <a className="floating-chat" href="#quote" aria-label="咨询纸袋项目"><MessageCircle size={22} /></a><a className="floating-quote" href="#quote">获取报价 <ArrowUpRight size={16} /></a>
    </div>
  );
}

createRoot(document.getElementById('root')).render(<App />);
